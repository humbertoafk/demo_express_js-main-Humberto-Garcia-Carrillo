const users = [
    { username: '1', password: '1' },
    { username: '2', password: '2' }
  ];
  
  module.exports = users;
  